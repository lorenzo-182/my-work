/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */


package com.mycompany.calculador;
import java.util.Scanner;
/**
 *
 * @author Papa Cerrano Lorenzo
 */
public class Calculador {

    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);

        // Declarar las variables necesarias
        int num1, num2;
        int mayor, menor;
        int resta;
        double division;

        // Solicitar el primer número entero
        System.out.print("Ingrese el primer número entero: ");
        num1= sc.nextInt();
        // >>> COMPLETAR AQUÍ <<<

        // Solicitar el segundo número entero
        System.out.print("Ingrese el segundo número entero: ");
        num2= sc.nextInt();
        // >>> COMPLETAR AQUÍ <<<


        // Determinar cuál es el mayor y cuál el menor
        if (num1>num2) {
            mayor= num1;
            menor= num2;
            // Asignar valores a mayor y menor
            // >>> COMPLETAR AQUÍ <<<
        } else {
            mayor= num2;
            menor= num1;
            // Asignar los valores contrarios
            // >>> COMPLETAR AQUÍ <<<
        }

        // Calcular la resta (mayor - menor)
        resta= mayor- menor;
        // >>> COMPLETAR AQUÍ <<<


        // Calcular la división (mayor / menor), solo si el menor es distinto de cero
        if (menor!=0) {
            division= mayor/menor;
            // Realizar la división (convertir a double si es necesario)
            // >>> COMPLETAR AQUÍ <<<

            // Mostrar resultados
            System.out.println("\nResultados:");
            System.out.println("Resta (mayor - menor): " + resta);
            System.out.println("División (mayor / menor): " + division);
        } else {
            // Mostrar mensaje si no se puede dividir
            System.out.println("\nResultados:");
            System.out.println("Resta (mayor - menor): " + resta);
            System.out.println("No se puede realizar la división porque el divisor es cero");
        }
    }
}


