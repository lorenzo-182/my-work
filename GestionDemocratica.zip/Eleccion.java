/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.eleccion;

import java.util.Scanner;
// Autor: Papa Cerrano Lorenzo

public class Eleccion {

    // ====== Atributos privados ======
    private Candidato[] candidatos;
    private int cantidad;
    private Scanner sc= new Scanner (System.in);

    // ====== Constructor ======
    public Eleccion(int maxCandidatos) {
        candidatos= new Candidato[maxCandidatos]; // Asigna la max cantidad que se ingresa por teclado
        cantidad= 0; // indica que no hay ninguno registrado
        // >>> COMPLETAR AQUÍ <<<  
        // Crear el vector con el tamaño indicado y establecer cantidad inicial en 0
    }

    // ====== Método para inscribir un candidato ======
    public void inscribirCandidato() {
      while( cantidad < candidatos.length){ // recorre hasta el ultimo elemento del vector por mas que sea nulo asi cargue perfecto
         
            System.out.println("Ingrese Nombre: ");
            String nombre= sc.nextLine();
            System.out.println("Ingrese Id: ");
            int id= sc.nextInt();
            sc.nextLine();
            candidatos[cantidad]= new Candidato (id, nombre);
            cantidad++;
      
      }
      if (cantidad == candidatos.length){
          System.out.println("No hay mas espacio para agregar candidatos.");
      }
       
        // >>> COMPLETAR AQUÍ <<<  
        // Verificar que haya espacio y agregar un nuevo objeto Candidato
    }

    // ====== Método para eliminar un candidato ======
    public void eliminarCandidato() {
        System.out.println("Ingrese un id: ");
        int id= sc.nextInt();
        boolean enc=false;
        sc.nextLine();
        for(int i=0; i< cantidad;i++){
            if (candidatos[i].getId()== id){
                for (int j=i; j<cantidad-1; j++){
                    candidatos[j]= candidatos[j+1];
                }
                enc=true;
               cantidad--;
            }
        }
        if(!enc){
            System.out.println("El id que ingreso no existe.");
        }
        // >>> COMPLETAR AQUÍ <<<  
        // Buscar candidato por id, eliminarlo y reorganizar el vector si es necesario
    }

    // ====== Método para registrar un voto ======
    public void registrarVoto() {
        System.out.println("Ingrese id del candidato que desea votar: ");
        int id= sc.nextInt();
        boolean enc=false;
        sc.nextLine();
        for(int i=0;i<cantidad;i++){
            if(id== candidatos[i].getId()){
                enc=true;
                candidatos[i].agregarVoto();
            }
        }
        if(!enc){
            System.out.println("El id ingresado no se encuentra registrado.");
        }
        // >>> COMPLETAR AQUÍ <<<  
        // Buscar candidato por id e incrementar su contador de votos
    }

    // ====== Método para consultar votos de un candidato ======
    public void consultarVotos() {
        System.out.println("Ingrese id del candidato: ");
        int id=sc.nextInt();
        boolean enc=false;
        sc.nextLine();
        for(int i=0; i< cantidad;i++){
        if(id== candidatos[i].getId()){
            enc= true;
            candidatos[i].mostrarCandidato();
        }
        // >>> COMPLETAR AQUÍ <<<  
        // Mostrar nombre y cantidad de votos
        }
        if(!enc){
            System.out.println("El id ingreesado no se encuentra registrado.");
        }
    }

    // ====== Método para mostrar todos los candidatos ======
    public void mostrarCandidatos() {
        for( int i=0; i<cantidad;i++){ // Recorre hasta el maximo cargado
            candidatos[i].mostrarCandidato();
        }
        // >>> COMPLETAR AQUÍ <<<  
        // Recorrer el vector e invocar mostrarCandidato() de cada uno
    }

    // ====== Método main ======
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese la cantidad máxima de candidatos: ");
        int max = sc.nextInt();
        sc.nextLine(); // limpiar buffer
        int op=-1;
        Eleccion eleccion = new Eleccion(max);
        while (op!= 0){
          System.out.println("1_Inscripcion de candidatos\n 2_Registro de votos \n3_Consultar votos \n4_Eliminacion de Candidato \n5_Listado de Candidatos \n0_Salir");
          op= sc.nextInt();
          sc.nextLine();
           switch (op){
            case 1-> eleccion.inscribirCandidato(); // --- Inscripción de candidatos ---
            case 2-> eleccion.registrarVoto(); // --- Registrar votos ---
            case 3-> eleccion.consultarVotos();  // --- Consultar votos ---
            case 4-> eleccion.eliminarCandidato();  // --- Mostrar listado general ---
            case 5-> eleccion.mostrarCandidatos(); // --- Eliminar candidato ---
            case 0-> System.out.println("Saliendo del programa");
        }
          
        }
       
    }
}
