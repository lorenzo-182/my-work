/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.eleccion;

/**
 *
 * @author Papa Cerrano Lorenzo
 */
public class Candidato {

    // ====== Atributos privados ======
    private int id;
    private String nombre;
    private int votos;
    private int CVotos;
    // ====== Constructor ======
    public Candidato(int id, String nombre) {
        this.nombre= nombre;
        this.id=id;
        this.votos=0;
        // >>> COMPLETAR AQUÍ <<<  // Inicializar id y nombre; votos debe iniciar en 0
    }

    // ====== Métodos get ======
    public int getId() {
        // >>> COMPLETAR AQUÍ <<<
        return id;
    }

    public String getNombre() {
        // >>> COMPLETAR AQUÍ <<<
        return nombre;
    }

    public int getVotos() {
        // >>> COMPLETAR AQUÍ <<<
        return votos;
    }

    // ====== Métodos funcionales ======
    public void agregarVoto() {
        
        CVotos++;
        // >>> COMPLETAR AQUÍ <<<  // Incrementar en uno el contador de votos
    }

    public void mostrarCandidato() {
        
        System.out.println(" |ID: "+ id +" |Nombre: "+ nombre +" |Votos: "+ CVotos);
        // >>> COMPLETAR AQUÍ <<<  
        // Ejemplo de salida: "ID: 1 | Nombre: Ana | Votos: 3"
    }
}
