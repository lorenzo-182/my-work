package com.mycompany.calculoedad;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
// CalculoEdad.java
// Autor: Papa Cerrano Lorenzo

import java.util.Scanner;

public class CalculoEdad {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Declarar variables necesarias
        String nombre;
        int anioNacimiento;
        int edad;
        final int ANIO_ACTUAL = 2025;

        // Solicitar el nombre de la persona
        do{
        System.out.print("Ingrese el nombre de la persona: ");
        nombre= sc.nextLine();
        nombre=nombre.trim();
        if (nombre.isEmpty()){
            System.out.println(" El nombre no puede ser vacio");
        }
         }while (nombre.isEmpty());
        
        // Leer el nombre desde teclado
        // >>> COMPLETAR AQUÍ <<<

        // Solicitar el año de nacimiento
        do{
        System.out.print("Ingrese el año de nacimiento (1950-2025): ");
        anioNacimiento= sc.nextInt();
        if (anioNacimiento<1950 || anioNacimiento>2025){
            System.out.println("El año de nacimiento tiene que estar dentro del rango");
                    
        }
         }while (anioNacimiento<1950 || anioNacimiento>2025);
        // Leer el año desde teclado
        // >>> COMPLETAR AQUÍ <<<
        edad= ANIO_ACTUAL - anioNacimiento;
  
        // Calcular la edad actual (año actual - año de nacimiento)
        // >>> COMPLETAR AQUÍ <<<

        // Mostrar el nombre y la edad calculada
        System.out.println("\nNombre: " + nombre);
        System.out.println("Edad: " + edad + " años");

        // Determinar si la persona es mayor o menor de edad
        if (edad >= 18) {
            System.out.println("Es mayor de edad");
        } else {
            System.out.println("Es menor de edad");
        }
    }
}